﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class JournalGUI : Form
    {
        string path = string.Empty;
        string journalPath = string.Empty;

        public JournalGUI()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (FolderBrowser.ShowDialog() == DialogResult.OK)
            {
                path = FolderBrowser.SelectedPath;
                PathLabel.Text = "Watched Folder Path: " + path;


                journalPath = path + "\\.journal";
                DirectoryInfo dir = Directory.CreateDirectory(journalPath);
                dir.Attributes = FileAttributes.Directory | FileAttributes.Hidden;


                CreateJournalFilesForExistingFiles();
                LoadFileList();
            }
            else
            {
                this.Close();
                return;
            }

            FileSystemWatcher FileWatch = new FileSystemWatcher();
            FileWatch.Path = path;
            FileWatch.EnableRaisingEvents = true;
            FileWatch.NotifyFilter = NotifyFilters.FileName | NotifyFilters.Size | NotifyFilters.Attributes;
            FileWatch.Changed += OnChange;
            FileWatch.Created += OnCreate;
            FileWatch.Deleted += OnDelete;
            FileWatch.Renamed += OnRename;


        }
        private void LoadFileList()
        {
            FilesListBox.Items.Clear();
            var files = Directory.GetFiles(path);
            foreach (var file in files)
            {
                FilesListBox.Items.Add(Path.GetFileName(file));
            }
        }

        private void CreateJournalFilesForExistingFiles()
        {
            var files = Directory.GetFiles(path, "*.txt");
            foreach (var file in files)
            {
                string journalFile = Path.Combine(journalPath, Path.GetFileNameWithoutExtension(file) + "_journal.txt");
                if (!File.Exists(journalFile))
                {
                    // Create the journal file if it doesn't exist
                    File.WriteAllText(journalFile, "Journal entry created for: " + Path.GetFileName(file) + Environment.NewLine);
                }
            }
        }

        private Dictionary<string, string[]> previousFileContent = new Dictionary<string, string[]>();

       private void OnChange(object sender, FileSystemEventArgs e)
{
    if (e.ChangeType == WatcherChangeTypes.Changed && e.FullPath.EndsWith(".txt"))
    {
        string[] currentLines = null;
        int attempts = 0;
        bool fileAccessedSuccessfully = false;

        // Retry logic for file access
        while (!fileAccessedSuccessfully && attempts < 3)
        {
            try
            {
                currentLines = File.ReadAllLines(e.FullPath); // Try reading the file
                fileAccessedSuccessfully = true;  // If we can read, exit loop
            }
            catch (IOException)
            {
                attempts++;
                if (attempts >= 3)
                {
                    MessageBox.Show($"Unable to access the file after {attempts} attempts. It may be locked by another process.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Wait for a short time before retrying
                System.Threading.Thread.Sleep(500);
            }
        }

        if (currentLines != null)
        {
            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(e.FullPath);

            if (previousFileContent.ContainsKey(fileNameWithoutExtension))
            {
                string[] previousLines = previousFileContent[fileNameWithoutExtension];

                // Compare the new lines with the old lines to find any changes
                int minLength = Math.Min(currentLines.Length, previousLines.Length);

                for (int i = 0; i < minLength; i++)
                {
                    // If the content is different at the current line, log it
                    if (currentLines[i] != previousLines[i])
                    {
                        LogToJournal(e.FullPath, "File changed", i + 1, currentLines[i]);
                    }
                }

                // Log any new lines (if currentLines is longer than previousLines)
                for (int i = minLength; i < currentLines.Length; i++)
                {
                    LogToJournal(e.FullPath, "File changed", i + 1, currentLines[i]);
                }
            }
            else
            {
                // If no previous content is available, log all lines
                for (int i = 0; i < currentLines.Length; i++)
                {
                    LogToJournal(e.FullPath, "File created", i + 1, currentLines[i]);
                }
            }

            // Update the previous content for future comparisons
            previousFileContent[fileNameWithoutExtension] = currentLines;
        }
    }
}
        private void OnCreate(object sender, FileSystemEventArgs e)
        {
            // Run the file operation on a background thread
            Task.Run(() =>
            {
                string filePath = e.FullPath;
                int maxAttempts = 10;
                int attempt = 0;

                while (attempt < maxAttempts)
                {
                    try
                    {
                        // Try opening the file for appending
                        using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                        {
                            // File successfully opened, log the event safely
                            UpdateUI(() => LogToJournal(filePath, "File created", -1, "File is created and ready."));
                            break;
                        }
                    }
                    catch (IOException)
                    {
                        // If file is in use, wait and try again
                        attempt++;
                        Thread.Sleep(500); // Wait 500ms before retrying
                    }
                }

                // If max attempts are reached, log failure
                if (attempt == maxAttempts)
                {
                    UpdateUI(() => LogToJournal(filePath, "File created", -1, "Failed to access file after several attempts."));
                }
            });
            
        }
        private void UpdateUI(Action action)
        {
            // Check if this is running on the UI thread
            if (InvokeRequired)
            {
                // Use Invoke to execute on the UI thread
                Invoke(action);
            }
            else
            {
                // Execute directly if already on UI thread
                action();
            }
        }
        private void OnDelete(object sender, FileSystemEventArgs e)
        {
            if (e.FullPath.EndsWith(".txt"))
            {

                this.Invoke((MethodInvoker)delegate
                {
                    try
                    {

                        if (File.Exists(e.FullPath))
                        {
                            File.Delete(e.FullPath);
                        }

                        string journalFilePath = Path.Combine(path, ".journal", Path.GetFileNameWithoutExtension(e.FullPath) + "_journal.txt");

                        if (File.Exists(journalFilePath))
                        {
                            File.Delete(journalFilePath);
                        }

                        LoadFileList();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting files: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                });
            }
        }

        private void OnRename(object sender, RenamedEventArgs e)
        {
            // Capture the old and new file names
            string oldFileName = e.OldFullPath;
            string newFileName = e.FullPath;

            // Create a log entry for the rename event
            string logMessage = $"[{DateTime.Now}] Renamed from: {oldFileName} to: {newFileName}{Environment.NewLine}";

            // Define the journal file path
            string journalFile = Path.Combine(journalPath, Path.GetFileNameWithoutExtension(newFileName) + "_journal.txt");

            // Append the log entry to the journal
            File.AppendAllText(journalFile, logMessage);

            // Optionally, if you want to track content changes after renaming, 
            // you can call the OnChange method for the renamed file.
            OnChange(sender, new FileSystemEventArgs(WatcherChangeTypes.Changed, Path.GetDirectoryName(newFileName), Path.GetFileName(newFileName)));

            LoadFileList();
        }

        private void Createbtn_Click(object sender, EventArgs e)
        {
            FileStream fstream;
            string name = string.Empty;
            bool exists = true;

            string filePath = string.Empty;

            while (exists)
            {
                if (CreateDialogBox("New File", "Please enter the name of the new file:", ref name) == DialogResult.OK)
                {

                    filePath = path + "\\" + name + ".txt";
                    name += ".txt";
                    exists = CheckFileExists(name);
                }
            }


            fstream = File.Create(filePath);
            Thread.Sleep(100);
            FilesListBox.Items.Add(Path.GetFileName(filePath));
            fstream.Close();
        }

        //private void Deletebtn_Click(object sender, EventArgs e)
        //{
        //    if (FilesListBox.SelectedIndex == -1)
        //    {
        //        MessageBox.Show("Please select a file to be deleted!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //    else
        //    {

        //        string fileName = path + "\\" + FilesListBox.SelectedItem.ToString();
        //        string journalFilePath = path + "\\.journal\\" + Path.GetFileNameWithoutExtension(FilesListBox.SelectedItem.ToString()) + "_journal.txt";

        //        try
        //        {

        //            if (File.Exists(fileName))
        //            {
        //                File.Delete(fileName);
        //            }


        //            if (File.Exists(journalFilePath))
        //            {
        //                File.Delete(journalFilePath);
        //            }


        //            FilesListBox.Items.Remove(FilesListBox.SelectedItem);
        //        }
        //        catch (Exception ex)
        //        {

        //            MessageBox.Show("Error deleting files: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        }
        //    }
        //}
        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (FilesListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a file to be deleted!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string fileName = path + "\\" + FilesListBox.SelectedItem.ToString();
                string journalFilePath = path + "\\.journal\\" + Path.GetFileNameWithoutExtension(FilesListBox.SelectedItem.ToString()) + "_journal.txt";

                try
                {
                    // Delete the actual file
                    if (File.Exists(fileName))
                    {
                        File.Delete(fileName);
                    }

                    // Rename the journal file instead of deleting it
                    if (File.Exists(journalFilePath))
                    {
                        string newJournalFileName = Path.Combine(path, ".journal", "Deleted_" + Path.GetFileName(FilesListBox.SelectedItem.ToString()));
                        string renamedJournalFilePath = Path.ChangeExtension(newJournalFileName, ".txt"); // Ensure it has the .txt extension

                        // Rename the journal file to "Deleted_<filename>"
                        File.Move(journalFilePath, renamedJournalFilePath);
                    }

                    // Remove the file from the list box
                    FilesListBox.Items.Remove(FilesListBox.SelectedItem);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting files: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void Renamebtn_Click(object sender, EventArgs e)
        {
           
        }


        private void Openbtn_Click(object sender, EventArgs e)
        {
            if (FilesListBox.SelectedItem != null)
            {
                string selectedFile = FilesListBox.SelectedItem.ToString();
                string fullPath = Path.Combine(path, selectedFile);
                Process.Start(fullPath);
            }
        }

        private void OpenJournalbtn_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("explorer.exe", journalPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Opening File Explorer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Rebuildbtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Ensure a file is selected in the FilesListBox
                if (FilesListBox.SelectedItem == null)
                {
                    MessageBox.Show("Please select a file from the Files list.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Get the file path from the FilesListBox
                string originalFilePath = Path.Combine(path, FilesListBox.SelectedItem.ToString());

                // Ensure the file exists before proceeding
                if (!File.Exists(originalFilePath))
                {
                    MessageBox.Show("The selected file does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Get the selected journal entry from the ListBox
                if (JournalListBox.SelectedItem == null)
                {
                    MessageBox.Show("Please select a journal entry to start rebuilding from.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string selectedEntry = JournalListBox.SelectedItem.ToString();

                // Extract the line number from the selected journal entry (assuming it's formatted like "line: X")
                int startLineNumber = ExtractLineNumber(selectedEntry);

                // If the extracted line number is invalid, show an error
                if (startLineNumber == -1)
                {
                    MessageBox.Show("Invalid journal entry. Cannot rebuild from this entry.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Call the method to rebuild the file using the journal entries
                RebuildFileFromJournal(originalFilePath, startLineNumber);
            }
            catch (Exception ex)
            {
                // Handle any errors during the rebuild process
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            LoadFileList();
        }

        private void RebuildFileFromJournal(string originalFilePath, int startLineNumber)
        {
            try
            {
                // Get the file name without extension to generate the rebuilt file name and journal file name
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(originalFilePath);
                string directory = Path.GetDirectoryName(originalFilePath); // Get directory of the original file

                // Define the rebuilt file path (rebuilt_ + original file name)
                string rebuiltFilePath = Path.Combine(directory, "rebuilt_" + fileNameWithoutExtension + Path.GetExtension(originalFilePath));

                // List to store the rebuilt file content
                List<string> rebuiltFileContent = new List<string>();

                // Create a new journal for the rebuilt file (this journal will just log the rebuild process)
                List<string> newJournal = new List<string>();

                // We assume the rebuilding starts from a specific line in the original file (instead of the journal)
                int currentLineNumber = 1; // Start line number for the rebuilt file

                // Read the original file and rebuild from the selected start line
                foreach (var line in File.ReadLines(originalFilePath))
                {
                    // If the current line number is greater than or equal to the start line number, start rebuilding
                    if (currentLineNumber >= startLineNumber)
                    {
                        rebuiltFileContent.Add(line);  // Apply the line to the rebuilt content

                        // Log this change into the new journal (for this rebuild)
                        string journalEntry = $"line: {currentLineNumber} change: {line}";
                       
                    }

                    currentLineNumber++;
                }

                // Save the rebuilt file
                File.WriteAllLines(rebuiltFilePath, rebuiltFileContent);

                // Generate the path for the new journal file (rebuilt_ + original file name + "_journal.txt")
                string rebuiltJournalPath = Path.Combine(directory, ".journal", "rebuilt_" + fileNameWithoutExtension + "_journal.txt");

                // Ensure the .journal folder exists
                Directory.CreateDirectory(Path.GetDirectoryName(rebuiltJournalPath));

                // Save the new journal to a file
                File.WriteAllLines(rebuiltJournalPath, newJournal);

                // Optionally, inform the user the rebuild was successful
                MessageBox.Show($"File successfully rebuilt! The new file is saved as {rebuiltFilePath}.\nThe new journal is saved as {rebuiltJournalPath}.", "Rebuild Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Handle any errors during the rebuild process
                MessageBox.Show("Error during rebuild: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int ExtractLineNumber(string journalEntry)
        {
            // Assuming the journal entry is formatted like "line: X change: ...", extract the line number
            var match = Regex.Match(journalEntry, @"line:\s*(\d+)");
            if (match.Success)
            {
                return int.Parse(match.Groups[1].Value);
            }
            return -1;
        }

       

        private void FilesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (FilesListBox.SelectedItem != null)
            {
                string selectedFile = FilesListBox.SelectedItem.ToString();
                string journalFilePath = Path.Combine(journalPath, Path.GetFileNameWithoutExtension(selectedFile) + "_journal.txt");


                JournalListBox.Items.Clear();

                if (File.Exists(journalFilePath))
                {
                    // Read all lines from the journal file
                    string[] journalContent = File.ReadAllLines(journalFilePath);

                    //divide journal.txt's into serperate lines for journalListBox
                    foreach (var line in journalContent)
                    {
                        JournalListBox.Items.Add(line);
                    }
                }
                else
                {
                    JournalListBox.Items.Add("No journal entry found.");
                }
            }
        }


        private bool CheckFileExists(string name)
        {

            foreach (string s in FilesListBox.Items)
            {
                //if the file exists return true
                if (s == name)
                {
                    MessageBox.Show("This file name already exists, please enter a new name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return true;
                }
            }
            return false;
        }

        private const int MaxJournalEntries = 20;  // Change the max journal entries to 20

        private void LogToJournal(string filePath, string message, int lineNumber, string newContent)
        {
            try
            {
                // Ensure the .journal directory exists
                string directoryPath = Path.Combine(Path.GetDirectoryName(filePath), ".journal");
                Directory.CreateDirectory(directoryPath);

                string journalFile = Path.Combine(directoryPath, Path.GetFileNameWithoutExtension(filePath) + "_journal.txt");

                string logMessage = $"[{DateTime.Now}] line: {lineNumber} change: {newContent}{Environment.NewLine}";

                bool writtenSuccessfully = false;
                int attempts = 0;

                // Exponential backoff for retry logic
                while (!writtenSuccessfully && attempts < 5)
                {
                    try
                    {
                        // Check if the journal file exists
                        if (File.Exists(journalFile))
                        {
                            // Read all current entries in the journal file
                            var journalEntries = File.ReadAllLines(journalFile).ToList();

                            // If the journal file has reached the max limit, remove the first line (oldest entry)
                            if (journalEntries.Count >= MaxJournalEntries)
                            {
                                journalEntries.RemoveAt(0);  // Remove the first (oldest) entry
                            }

                            // Add the new log message
                            journalEntries.Add(logMessage);

                            // Write the updated journal entries back to the file
                            File.WriteAllLines(journalFile, journalEntries);
                        }
                        else
                        {
                            // If the file doesn't exist, create it and write the log message
                            File.WriteAllText(journalFile, logMessage);
                        }

                        writtenSuccessfully = true;  // If successful, set to true
                    }
                    catch (IOException ex)
                    {
                        attempts++;
                        if (attempts >= 5)
                        {
                            MessageBox.Show($"Failed to write to journal file after {attempts} attempts. The file may be locked by another process.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        }

                        // Exponential backoff for retrying
                        System.Threading.Thread.Sleep((int)Math.Pow(2, attempts) * 500);  // Wait time increases exponentially
                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        MessageBox.Show($"Access denied: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
     
        //message box to be reused
        private DialogResult CreateDialogBox(string title, string request, ref string value)
        {
            //Create a new Dialog Box to ask the user for the file name
            Form form = new Form();
            Label label = new Label();
            Label label2 = new Label();
            TextBox textBox = new TextBox();
            Button buttonOK = new Button();
            Font font = new Font(FontFamily.GenericSansSerif, (float)15);

            //set the text to each element
            form.Text = title;
            label.Text = request;
            label2.Text = ".txt";

            //set the font for each element
            label.Font = font;
            label2.Font = font;
            buttonOK.Font = font;

            //set the buttons to ok and cancel
            buttonOK.Text = "OK";
            buttonOK.DialogResult = DialogResult.OK;

            //Place the elements in the dialog box
            label.SetBounds(10, 30, 372, 20);
            label2.SetBounds(280, 60, 40, 20);
            textBox.SetBounds(20, 60, 280, 20);
            buttonOK.SetBounds(30, 100, 140, 30);

            //General size properties
            label.AutoSize = true;
            label2.AutoSize = true;
            form.ClientSize = new Size(350, 150);
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.MinimizeBox = false;
            form.MaximizeBox = false;

            //allow the elements to show up
            form.Controls.AddRange(new Control[] { label, label2, textBox, buttonOK });
            form.AcceptButton = buttonOK;

            DialogResult dialogResult = form.ShowDialog();

            value = textBox.Text;
            return dialogResult;
        }
    }
}
