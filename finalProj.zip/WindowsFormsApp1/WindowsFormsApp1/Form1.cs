﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class JournalGUI : Form
    {
        private string path = string.Empty;
        private string journalPath = string.Empty;

        public JournalGUI()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (FolderBrowser.ShowDialog() == DialogResult.OK)
            {
                path = FolderBrowser.SelectedPath;
                PathLabel.Text = "Watched Folder Path: " + path;
                journalPath = path + "\\.journal";
                Directory.CreateDirectory(journalPath);  // Ensure the journal folder exists
                LoadFileList();
                SetUpFileWatcher();
            }
            else
            {
                this.Close();
            }
        }

        private void SetUpFileWatcher()
        {
            FileSystemWatcher fileWatcher = new FileSystemWatcher
            {
                Path = path,
                EnableRaisingEvents = true,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.Size | NotifyFilters.Attributes
            };
            fileWatcher.Created += OnFileCreated;
            fileWatcher.Deleted += OnFileDeleted;
            fileWatcher.Renamed += OnFileRenamed;
            fileWatcher.Changed += OnFileChanged;
        }

        private void LoadFileList()
        {
            FilesListBox.Items.Clear();
            foreach (var file in Directory.GetFiles(path))
            {
                FilesListBox.Items.Add(Path.GetFileName(file));
            }
        }

        private void OnFileCreated(object sender, FileSystemEventArgs e)
        {
            if (e.FullPath.EndsWith(".txt"))
            {
                LogToJournal(e.FullPath, "File created", -1, "File created successfully.");
            }
        }

        private void OnFileDeleted(object sender, FileSystemEventArgs e)
        {
            if (e.FullPath.EndsWith(".txt"))
            {
                string journalFilePath = Path.Combine(journalPath, Path.GetFileNameWithoutExtension(e.FullPath) + "_journal.txt");
                if (File.Exists(journalFilePath))
                {
                    File.Delete(journalFilePath); // Delete journal when file is deleted
                }
                LoadFileList();
            }
        }

        private void OnFileRenamed(object sender, RenamedEventArgs e)
        {
            string logMessage = $"[{DateTime.Now}] Renamed from: {e.OldFullPath} to: {e.FullPath}{Environment.NewLine}";
            string journalFile = Path.Combine(journalPath, Path.GetFileNameWithoutExtension(e.FullPath) + "_journal.txt");
            File.AppendAllText(journalFile, logMessage);
        }

        private void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            if (e.FullPath.EndsWith(".txt"))
            {
                string[] lines = File.ReadAllLines(e.FullPath);
                for (int i = 0; i < lines.Length; i++)
                {
                    LogToJournal(e.FullPath, "File changed", i + 1, lines[i]);
                }
            }
        }

        private void LogToJournal(string filePath, string message, int lineNumber, string newContent)
        {
            string journalFile = Path.Combine(journalPath, Path.GetFileNameWithoutExtension(filePath) + "_journal.txt");
            string logMessage = $"[{DateTime.Now}] {message} (Line {lineNumber}): {newContent}{Environment.NewLine}";

            // Ensure the journal file exists
            if (!File.Exists(journalFile))
            {
                // If not, create it
                File.WriteAllText(journalFile, logMessage);
                return;
            }

            // Read existing journal entries
            var journalEntries = File.ReadAllLines(journalFile).ToList();

            // If the journal has reached the max limit of lines, remove the oldest entry (first line)
            if (journalEntries.Count >= 20)
            {
                journalEntries.RemoveAt(0);  // Remove the first (oldest) line
            }

            // Add the new log message to the journal
            journalEntries.Add(logMessage);

            // Write the updated journal entries back to the file
            File.WriteAllLines(journalFile, journalEntries);
        }

        private bool CheckFileExists(string name)
        {
            foreach (string s in FilesListBox.Items)
            {
                if (s == name)
                {
                    MessageBox.Show("This file name already exists, please enter a new name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return true;
                }
            }
            return false;
        }

        // Event handler for the "Create" button
        private void Createbtn_Click(object sender, EventArgs e)
        {
            string name = string.Empty;
            bool exists = true;

            while (exists)
            {
                if (CreateDialogBox("New File", "Please enter the name of the new file:", ref name) == DialogResult.OK)
                {
                    string filePath = Path.Combine(path, name);  // Use the directory path for file creation
                    string directoryPath = Path.GetDirectoryName(filePath);  // Get the directory path from the file path

                    // Ensure the directory exists before creating the file
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);  // Create the directory if it doesn't exist
                    }

                    exists = CheckFileExists(name);
                    if (!exists)
                    {
                        File.Create(filePath).Close();  // Create the file
                        FilesListBox.Items.Add(name);
                    }
                }
            }
        }

        // Event handler for file selection in the FilesListBox
        private void FilesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (FilesListBox.SelectedItem != null)
            {
                string fileName = FilesListBox.SelectedItem.ToString();
                string journalFilePath = Path.Combine(journalPath, Path.GetFileNameWithoutExtension(fileName) + "_journal.txt");

                JournalListBox.Items.Clear();

                if (File.Exists(journalFilePath))
                {
                    string[] journalContent = File.ReadAllLines(journalFilePath);
                    foreach (var line in journalContent)
                    {
                        JournalListBox.Items.Add(line);
                    }
                }
                else
                {
                    JournalListBox.Items.Add("No journal entry found.");
                }
            }
        }

        // Event handler for the "Delete" button
        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (FilesListBox.SelectedItem != null)
            {
                string fileName = FilesListBox.SelectedItem.ToString();
                string filePath = Path.Combine(path, fileName);
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                    FilesListBox.Items.Remove(fileName);
                }
            }
        }

        // Event handler for the "Rename" button
        private void Renamebtn_Click(object sender, EventArgs e)
        {
            if (FilesListBox.SelectedItem != null)
            {
                string oldFileName = FilesListBox.SelectedItem.ToString();
                string newFileName = ShowInputDialog("Enter new file name:", oldFileName);

                if (!string.IsNullOrEmpty(newFileName) && newFileName != oldFileName)
                {
                    string oldFilePath = Path.Combine(path, oldFileName);
                    string newFilePath = Path.Combine(path, newFileName);

                    if (!File.Exists(newFilePath))
                    {
                        File.Move(oldFilePath, newFilePath);
                        FilesListBox.Items[FilesListBox.SelectedIndex] = newFileName;
                    }
                    else
                    {
                        MessageBox.Show("A file with the new name already exists.");
                    }
                }
            }
        }

        // Custom input dialog for renaming a file
        private string ShowInputDialog(string prompt, string defaultValue)
        {
            Form promptForm = new Form();
            promptForm.Width = 300;
            promptForm.Height = 150;
            promptForm.Text = prompt;

            Label label = new Label() { Left = 10, Top = 20, Text = prompt };
            TextBox inputBox = new TextBox() { Left = 10, Top = 50, Width = 260, Text = defaultValue };
            Button confirmationButton = new Button() { Text = "OK", Left = 200, Width = 75, Top = 80, DialogResult = DialogResult.OK };

            confirmationButton.Click += (sender, e) => { promptForm.Close(); };

            promptForm.Controls.Add(label);
            promptForm.Controls.Add(inputBox);
            promptForm.Controls.Add(confirmationButton);
            promptForm.AcceptButton = confirmationButton;

            if (promptForm.ShowDialog() == DialogResult.OK)
            {
                return inputBox.Text;
            }

            return string.Empty;
        }


        private void Rebuildbtn_Click(object sender, EventArgs e)
        {
            // Check if a file is selected in the FilesListBox
            if (FilesListBox.SelectedItem != null)
            {
                string fileName = FilesListBox.SelectedItem.ToString();
                string filePath = Path.Combine(path, fileName);
                string journalFilePath = Path.Combine(journalPath, Path.GetFileNameWithoutExtension(fileName) + "_journal.txt");

                // Check if the journal file exists
                if (File.Exists(journalFilePath))
                {
                    // Initialize a list to store rebuilt content
                    List<string> rebuiltContent = new List<string>();

                    // Read journal entries and rebuild the file content
                    string[] journalEntries = File.ReadAllLines(journalFilePath);

                    // Add each journal entry to the rebuilt content
                    foreach (var entry in journalEntries)
                    {
                        // Assuming the journal entry contains a line with the file's changes
                        rebuiltContent.Add(entry);
                    }

                    // Rebuild the original file from the journal content
                    try
                    {
                        // Create or overwrite the original file with the rebuilt content
                        File.WriteAllLines(filePath, rebuiltContent);

                        // Notify the user that the file was rebuilt successfully
                        MessageBox.Show("File has been successfully rebuilt from the journal.", "Rebuild Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // Handle any errors during the rebuild process
                        MessageBox.Show("An error occurred while rebuilding the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    // If no journal file exists for the selected file
                    MessageBox.Show("No journal file found to rebuild the content.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                // If no file is selected
                MessageBox.Show("Please select a file to rebuild.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        // Event handler for the "Open" button
        private void Openbtn_Click(object sender, EventArgs e)
        {
            if (FilesListBox.SelectedItem != null)
            {
                string fileName = FilesListBox.SelectedItem.ToString();
                string filePath = Path.Combine(path, fileName);
                Process.Start(filePath);
            }
        }

        // Event handler for the "Open Journal" button
        private void OpenJournalbtn_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("explorer.exe", journalPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening the journal folder: " + ex.Message);
            }
        }

        // Method to show a dialog box for creating a new file
        private DialogResult CreateDialogBox(string title, string request, ref string value)
        {
            Form form = new Form();
            TextBox textBox = new TextBox();
            Button buttonOK = new Button();

            form.Text = title;
            buttonOK.Text = "OK";
            buttonOK.DialogResult = DialogResult.OK;
            textBox.Text = value;

            form.Controls.Add(textBox);
            form.Controls.Add(buttonOK);
            form.AcceptButton = buttonOK;

            return form.ShowDialog();
        }
    }
}
