﻿namespace WindowsFormsApp1
{
    partial class JournalGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FolderBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.FileWatch = new System.IO.FileSystemWatcher();
            this.FilesListBox = new System.Windows.Forms.ListBox();
            this.JournalListBox = new System.Windows.Forms.ListBox();
            this.FileLabel = new System.Windows.Forms.Label();
            this.JournalBoxLabel = new System.Windows.Forms.Label();
            this.PathLabel = new System.Windows.Forms.Label();
            this.Createbtn = new System.Windows.Forms.Button();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.Renamebtn = new System.Windows.Forms.Button();
            this.Rebuildbtn = new System.Windows.Forms.Button();
            this.Openbtn = new System.Windows.Forms.Button();
            this.OpenJournalbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.FileWatch)).BeginInit();
            this.SuspendLayout();
            // 
            // FileWatch
            // 
            this.FileWatch.EnableRaisingEvents = true;
            this.FileWatch.Filter = "*.txt";  // Fixed the filter
            this.FileWatch.SynchronizingObject = this;
            // 
            // FilesListBox
            // 
            this.FilesListBox.FormattingEnabled = true;
            this.FilesListBox.ItemHeight = 16;
            this.FilesListBox.Location = new System.Drawing.Point(12, 49);
            this.FilesListBox.Name = "FilesListBox";
            this.FilesListBox.Size = new System.Drawing.Size(441, 196);
            this.FilesListBox.TabIndex = 0;
            this.FilesListBox.SelectedIndexChanged += new System.EventHandler(this.FilesListBox_SelectedIndexChanged);
            // 
            // JournalListBox
            // 
            this.JournalListBox.FormattingEnabled = true;
            this.JournalListBox.ItemHeight = 16;
            this.JournalListBox.Location = new System.Drawing.Point(12, 305);
            this.JournalListBox.Name = "JournalListBox";
            this.JournalListBox.Size = new System.Drawing.Size(1055, 228);
            this.JournalListBox.TabIndex = 1;
            // 
            // FileLabel
            // 
            this.FileLabel.AutoSize = true;
            this.FileLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.FileLabel.Location = new System.Drawing.Point(12, 9);
            this.FileLabel.Name = "FileLabel";
            this.FileLabel.Size = new System.Drawing.Size(174, 29);
            this.FileLabel.TabIndex = 2;
            this.FileLabel.Text = "Files Watched";
            // 
            // JournalBoxLabel
            // 
            this.JournalBoxLabel.AutoSize = true;
            this.JournalBoxLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.JournalBoxLabel.Location = new System.Drawing.Point(12, 264);
            this.JournalBoxLabel.Name = "JournalBoxLabel";
            this.JournalBoxLabel.Size = new System.Drawing.Size(175, 29);
            this.JournalBoxLabel.TabIndex = 3;
            this.JournalBoxLabel.Text = "Journal Entries";
            // 
            // PathLabel
            // 
            this.PathLabel.AutoSize = true;
            this.PathLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.PathLabel.Location = new System.Drawing.Point(12, 542);
            this.PathLabel.Name = "PathLabel";
            this.PathLabel.Size = new System.Drawing.Size(257, 29);
            this.PathLabel.TabIndex = 4;
            this.PathLabel.Text = "Watched Folder Path:";
            // 
            // Createbtn
            // 
            this.Createbtn.BackColor = System.Drawing.SystemColors.Window;
            this.Createbtn.Location = new System.Drawing.Point(486, 50);
            this.Createbtn.Name = "Createbtn";
            this.Createbtn.Size = new System.Drawing.Size(122, 47);
            this.Createbtn.TabIndex = 5;
            this.Createbtn.Text = "Create";
            this.Createbtn.UseVisualStyleBackColor = false;
            this.Createbtn.Click += new System.EventHandler(this.Createbtn_Click);
            // 
            // Deletebtn
            // 
            this.Deletebtn.Location = new System.Drawing.Point(486, 124);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(122, 47);
            this.Deletebtn.TabIndex = 6;
            this.Deletebtn.Text = "Delete";
            this.Deletebtn.UseVisualStyleBackColor = true;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click);
            // 
            // Renamebtn
            // 
            this.Renamebtn.Location = new System.Drawing.Point(486, 199);
            this.Renamebtn.Name = "Renamebtn";
            this.Renamebtn.Size = new System.Drawing.Size(122, 47);
            this.Renamebtn.TabIndex = 7;
            this.Renamebtn.Text = "Rename";
            this.Renamebtn.UseVisualStyleBackColor = true;
            this.Renamebtn.Click += new System.EventHandler(this.Renamebtn_Click);
            // 
            // Rebuildbtn
            // 
            this.Rebuildbtn.Location = new System.Drawing.Point(708, 199);
            this.Rebuildbtn.Name = "Rebuildbtn";
            this.Rebuildbtn.Size = new System.Drawing.Size(122, 47);
            this.Rebuildbtn.TabIndex = 8;
            this.Rebuildbtn.Text = "Rebuild";
            this.Rebuildbtn.UseVisualStyleBackColor = true;
            this.Rebuildbtn.Click += new System.EventHandler(this.Rebuildbtn_Click);
            // 
            // Openbtn
            // 
            this.Openbtn.Location = new System.Drawing.Point(708, 50);
            this.Openbtn.Name = "Openbtn";
            this.Openbtn.Size = new System.Drawing.Size(122, 47);
            this.Openbtn.TabIndex = 9;
            this.Openbtn.Text = "Open File";
            this.Openbtn.UseVisualStyleBackColor = true;
            this.Openbtn.Click += new System.EventHandler(this.Openbtn_Click);
            // 
            // OpenJournalbtn
            // 
            this.OpenJournalbtn.Location = new System.Drawing.Point(708, 124);
            this.OpenJournalbtn.Name = "OpenJournalbtn";
            this.OpenJournalbtn.Size = new System.Drawing.Size(122, 47);
            this.OpenJournalbtn.TabIndex = 10;
            this.OpenJournalbtn.Text = "Journal Folder";
            this.OpenJournalbtn.UseVisualStyleBackColor = true;
            this.OpenJournalbtn.Click += new System.EventHandler(this.OpenJournalbtn_Click);
            // 
            // JournalGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1079, 580);
            this.Controls.Add(this.OpenJournalbtn);
            this.Controls.Add(this.Openbtn);
            this.Controls.Add(this.Rebuildbtn);
            this.Controls.Add(this.Renamebtn);
            this.Controls.Add(this.Deletebtn);
            this.Controls.Add(this.Createbtn);
            this.Controls.Add(this.PathLabel);
            this.Controls.Add(this.JournalBoxLabel);
            this.Controls.Add(this.FileLabel);
            this.Controls.Add(this.JournalListBox);
            this.Controls.Add(this.FilesListBox);
            this.Name = "JournalGUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Journal Manager";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FileWatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog FolderBrowser;
        private System.IO.FileSystemWatcher FileWatch;
        private System.Windows.Forms.Label FileLabel;
        private System.Windows.Forms.ListBox JournalListBox;
        private System.Windows.Forms.ListBox FilesListBox;
        private System.Windows.Forms.Label JournalBoxLabel;
        private System.Windows.Forms.Label PathLabel;
        private System.Windows.Forms.Button Renamebtn;
        private System.Windows.Forms.Button Deletebtn;
        private System.Windows.Forms.Button Createbtn;
        private System.Windows.Forms.Button OpenJournalbtn;
        private System.Windows.Forms.Button Openbtn;
        private System.Windows.Forms.Button Rebuildbtn;
    }
}
